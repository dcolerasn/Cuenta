import java.util.concurrent.Semaphore;

public class SacarDinero extends Thread implements Runnable{

		private Cuenta c;
		String nom;
		private Semaphore sem = new Semaphore(1);
		
		public SacarDinero(String n, Cuenta c) {
			super (n);
			this.c = c;
		}
		
		public void run() {
			
			for (int x = 1; x<=4; x++) {
				try {
					sem.acquire();
					c.RetirarDinero(10, getName());
				}
				 catch (InterruptedException e) {
					e.printStackTrace();
				}
				finally {
					sem.release();
				}
			}
		}// run
}
